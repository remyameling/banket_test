<?php

require_once APPLICATION_PATH.Zend_Registry::getInstance()->paths->components."BaseController.php";

class Stilstand_BaseController extends RACCMS_Component_BaseController
{
	protected $_form 			= NULL;
	protected $_redirector  	= NULL;
	
		
	public function init()
	{
    	$this->_redirector 		= $this->_helper->getHelper('Redirector');	
    	    		
        return parent::init();        
    }
    
	protected function _getForm($form="add")
    {
		if (NULL === $this->_form){
			
			$config = Zend_Registry::getInstance()->stilstand_forms->get(strtolower($this->_domain_name));
			
			if ($config === NULL)
				throw new Exception("BaseController::_getForm(".$form."): geen formulier entry gevonden voor ".$this->_domain_name." in forms.ini");
			
			assert($config !== NULL);
			
			$this->_form = new RAC_Component_Form($config,$form);
		}
		return $this->_form;
	}
	
	
	protected function _initRegistratieForm($form)
    {
    	// bepaal lijnummers van deze site
    	$lijninfo 	= Zend_Registry::getInstance()->sites->lijn->get($this->_getCurrentSiteName())->toArray();
    	foreach($lijninfo as $idx=>$lijndata)
    		$lijnen[$idx] = $lijndata['naam'];
    		
    	//$this->p($lijnen,1);
    	
    	// bepaal categorieen voor deze site    		
    	$categorien = Zend_Registry::getInstance()->stilstand_consts->cat->get($this->_getCurrentSiteName())->toArray();
    	
    	//$this->p($categorien,1);
    	
    	// maak array van categorieen per lijn 
    	foreach($lijnen as $lijnid=>$lijn)
    	{
    		$cats                = Zend_Registry::getInstance()->stilstand_consts->lijn->get($lijnid);
    		//$this->p($cats,1);
    		
    		if ($cats !== NULL)									// indien deze lijn categorieen heeft gekoppeld
    			$catperlijn[$lijnid] = explode(",",$cats);
    		else												// zoniet, lijn verwijderen uit lijnnummers array
    			unset($lijnen[$lijnid]);
    	}
		
		// bepaal categorieen voor deze site    		
    	$locaties = Zend_Registry::getInstance()->stilstand_consts->locatie->get($this->_getCurrentSiteName())->toArray();    	
    	//$this->p($locaties,1);
    	
    	// maak array van locaties per lijn 
    	foreach($lijnen as $lijnid=>$lijn)
    	{
    		$locs   = Zend_Registry::getInstance()->stilstand_consts->lijnloc->get($lijnid);
    		//$this->p($locs,1);
    		
    		if ($locs !== NULL)									// indien deze lijn categorieen heeft gekoppeld
    			$locperlijn[$lijnid] = explode(",",$locs);
    		else												// zoniet, lijn verwijderen uit lijnnummers array
    			$locperlijn[$lijnid] = array();
    	}
    	
    	// tovoegen lijnnummers aan formulier element
    	$select = $form->getElement("lijnnr");
    	$select->addMultiOptions($lijnen);
    	
    	
    	// maak filter waardes array (value#filter)
    	foreach($catperlijn as $lijn=>$cats)
    	{
    		foreach($cats as $categorie){
    			
    			if (!isset($categorien[$categorie])){
    				$this->p($cats,1);
    				throw new Exception("Categorie $categorie not set");
    			}
    			
    			$values["$categorie#$lijn"] = $categorien[$categorie];
    		}
    	}
		
		// maak filter waardes array (value#filter)
    	foreach($locperlijn as $lijn=>$locs)
    	{
    		foreach($locs as $locatie){
    			
    			if (!isset($locaties[$locatie])){
    				$this->p($locs,1);
    				throw new Exception("Locatie $locatie not set");
    			}
    			
    			$locvalues["$locatie#$lijn"] = $locaties[$locatie];
    		}
    	}
    	
    	// bepaal diensten voor deze site    	
    	$diensten 	= Zend_Registry::getInstance()->sites->dienst->get($this->_getCurrentSiteName())->naam->toArray();
    	$select 	= $form->getElement("dienst_id");
    	$select->addMultiOptions($diensten);
    	
    	// bepaal huidige dienst a.d.h.v. huidige tijd
    	$dienst_id 	= $this->getCurrentDienstId();
    	$select->setValue($dienst_id);
    	
    	// toevoegen filter waardes aan formulier element    		
    	$select = $form->getElement("categorie");
    	$select->addMultiOptions($values);	
		
		// toevoegen filter waardes aan formulier element    		
    	$select = $form->getElement("subcategorie");
    	$select->addMultiOptions($locvalues);	
    	
    	/*
    	$configFileName = Zend_Registry::getInstance()->stilstand_forms->registratie;    	
    	$cfg = new Zend_Config_Ini(APPLICATION_PATH."/".$configFileName, APPLICATION_ENV);    	
    	$form = $this->removeHiddenFields($form,$cfg->hide->registratie,$this->_getCurrentSiteName());
    	*/
    	
    	return $form;
    }
    
	
}